#!/bin/bash

 # change this value to your "Project Id" found on the Project Settings -> API page in dashboard
PROJECT_ID=''

# change this value to your "Smartling API key" found on the Project Settings -> API page in dashboard
API_KEY=''

# the File API URL to use
API_SERVICE_URL=api.smartling.com # production
#API_SERVICE_URL=sandbox-api.smartling.com # sandbox

# the File API version to use
API_VERSION='v1'
